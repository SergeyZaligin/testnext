<template>
  <section class="container">

  </section>
</template>

<script>

export default {}

</script>

<style>
.container {
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
}
</style>
