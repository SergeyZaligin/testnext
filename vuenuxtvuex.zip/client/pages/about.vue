<template>
  <h1>About Secret page</h1>
</template>

<script>

export default {
  middleware: 'authenticated'
}


</script>
