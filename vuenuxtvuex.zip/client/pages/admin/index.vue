<template>
  <h1>Admin Secret page</h1>
</template>

<script>

export default {
  layout: 'admin'
}

</script>
