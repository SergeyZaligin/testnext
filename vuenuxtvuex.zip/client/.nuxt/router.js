import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const _0c5a4cc8 = () => import('../pages/registration.vue' /* webpackChunkName: "pages/registration" */).then(m => m.default || m)
const _22e2712c = () => import('../pages/login.vue' /* webpackChunkName: "pages/login" */).then(m => m.default || m)
const _052f498e = () => import('../pages/about.vue' /* webpackChunkName: "pages/about" */).then(m => m.default || m)
const _455b82d3 = () => import('../pages/admin/index.vue' /* webpackChunkName: "pages/admin/index" */).then(m => m.default || m)
const _a8325262 = () => import('../pages/admin/articles/index.vue' /* webpackChunkName: "pages/admin/articles/index" */).then(m => m.default || m)
const _b291f760 = () => import('../pages/admin/category/index.vue' /* webpackChunkName: "pages/admin/category/index" */).then(m => m.default || m)
const _31c3d3c2 = () => import('../pages/admin/category/add.vue' /* webpackChunkName: "pages/admin/category/add" */).then(m => m.default || m)
const _16ce7c5e = () => import('../pages/admin/articles/add.vue' /* webpackChunkName: "pages/admin/articles/add" */).then(m => m.default || m)
const _cdb9a4e0 = () => import('../pages/admin/category/list.vue' /* webpackChunkName: "pages/admin/category/list" */).then(m => m.default || m)
const _2a24b1e6 = () => import('../pages/admin/category/update/_id.vue' /* webpackChunkName: "pages/admin/category/update/_id" */).then(m => m.default || m)
const _11f1e032 = () => import('../pages/article/_slug.vue' /* webpackChunkName: "pages/article/_slug" */).then(m => m.default || m)
const _534bac2a = () => import('../pages/articles/_page.vue' /* webpackChunkName: "pages/articles/_page" */).then(m => m.default || m)
const _24e72453 = () => import('../pages/index.vue' /* webpackChunkName: "pages/index" */).then(m => m.default || m)



if (process.client) {
  window.history.scrollRestoration = 'manual'
}
const scrollBehavior = function (to, from, savedPosition) {
  // if the returned position is falsy or an empty object,
  // will retain current scroll position.
  let position = false

  // if no children detected
  if (to.matched.length < 2) {
    // scroll to the top of the page
    position = { x: 0, y: 0 }
  } else if (to.matched.some((r) => r.components.default.options.scrollToTop)) {
    // if one of the children has scrollToTop option set to true
    position = { x: 0, y: 0 }
  }

  // savedPosition is only available for popstate navigations (back button)
  if (savedPosition) {
    position = savedPosition
  }

  return new Promise(resolve => {
    // wait for the out transition to complete (if necessary)
    window.$nuxt.$once('triggerScroll', () => {
      // coords will be used if no selector is provided,
      // or if the selector didn't match any element.
      if (to.hash) {
        let hash = to.hash
        // CSS.escape() is not supported with IE and Edge.
        if (typeof window.CSS !== 'undefined' && typeof window.CSS.escape !== 'undefined') {
          hash = '#' + window.CSS.escape(hash.substr(1))
        }
        try {
          if (document.querySelector(hash)) {
            // scroll to anchor by returning the selector
            position = { selector: hash }
          }
        } catch (e) {
          console.warn('Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).')
        }
      }
      resolve(position)
    })
  })
}


export function createRouter () {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,
    routes: [
		{
			path: "/registration",
			component: _0c5a4cc8,
			name: "registration"
		},
		{
			path: "/login",
			component: _22e2712c,
			name: "login"
		},
		{
			path: "/about",
			component: _052f498e,
			name: "about"
		},
		{
			path: "/admin",
			component: _455b82d3,
			name: "admin"
		},
		{
			path: "/admin/articles",
			component: _a8325262,
			name: "admin-articles"
		},
		{
			path: "/admin/category",
			component: _b291f760,
			name: "admin-category"
		},
		{
			path: "/admin/category/add",
			component: _31c3d3c2,
			name: "admin-category-add"
		},
		{
			path: "/admin/articles/add",
			component: _16ce7c5e,
			name: "admin-articles-add"
		},
		{
			path: "/admin/category/list",
			component: _cdb9a4e0,
			name: "admin-category-list"
		},
		{
			path: "/admin/category/update/:id?",
			component: _2a24b1e6,
			name: "admin-category-update-id"
		},
		{
			path: "/article/:slug?",
			component: _11f1e032,
			name: "article-slug"
		},
		{
			path: "/articles/:page?",
			component: _534bac2a,
			name: "articles-page"
		},
		{
			path: "/",
			component: _24e72453,
			name: "index"
		}
    ],
    
    
    fallback: false
  })
}
