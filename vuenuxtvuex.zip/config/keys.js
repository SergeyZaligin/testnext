module.exports = {
    mongoURI: 'mongodb://admindb:123456t@ds125183.mlab.com:25183/fullstack',
    secretKey: 'jwt-dev'
}